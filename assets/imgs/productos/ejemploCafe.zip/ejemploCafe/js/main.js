let nombre = prompt("Ingrese su nombre, por favor: ");
let cafe = prompt("Buenos dias, deseas tomar cafe");
let acompaniamiento = "";

// Validamos si el usuario no ingreso nada
if(nombre == "" && cafe == ""){

    // mensaje que se ejecutara si el usuario no ingreso nada
    console.log(`${nombre}, por favor debes ingresar valores`);

    // Si el usuario ingreso algo se ejecuta el else
}else {

    console.log("Genio ingresaste texto")

    // validadamos que nombre y cafe no sean numeros
    if(!isNaN(nombre)){
        console.log("El nombre nombre no puede ser un numero");
    }

    if(!isNaN(cafe)){
        console.log("El cafe no puede ser un numero");
    }

    // Aca se podria usar los metodos .toLowerCase() y .toUpperCase()
    // Se los dejo de tarea si quieren, pero lo hice asi a proposito
    // para enredarlos

    // Como veran hice if dentro de if, se llaman if anidados
    if(cafe == "si" || cafe == "Si" || cafe == "SI"){
        
        // Aca use backticks olvidarme de los saltos de linea
        // al usar estas comillas inclinadas puedo hacer saltos
        // de linea super tranqui, y notaran que uso esto ${nombre}
        // de esa manera se usa las variables dentro de las backtick
    
        let tipoDeCafe = prompt(` ${nombre}
        Que tipo de cafe deseas tomar?
        
        * Capuchino
        * Latte
        * Cortado
        * Mocha
        * Chocolate
    
        `);
        
        if(tipoDeCafe == "capuchino" || tipoDeCafe == "Capuchino"){
            alert("Elegiste un capuchino");
    
            acompaniamiento = prompt(`
            ${nombre} con que queres acompañar tu capuchino ?
    
            * Huevos revueltos 
            * Sandwich de jamon y queso
            * Pan de dulce de leche
            * Frutas
            `)
    
            if(acompaniamiento == "Huevos revueltos" || acompaniamiento == "huevos revueltos"){
                console.log(`${nombre}, disfruta de tu cafe y huevos revueltos`);
            }
            else if(acompaniamiento == "Sandwich de jamon y queso" || acompaniamiento == "sandwich de jamon y queso"){
                console.log(`${nombre}, disfruta de tu cafe y sandwich de jamon y queso`);
            }
            else if(acompaniamiento == "Pan de dulce de leche" || acompaniamiento == "pan de dulce de leche"){
                console.log(`${nombre}, disfruta de tu cafe y pan de dulce de leche`);
            }
            else if(acompaniamiento == "Frutas" || acompaniamiento == "frutas"){
                console.log(`${nombre}, disfruta de tu cafe y tus frutas`);
            }
            else{
                console.log("Elegiste nada");
            }
    
        }
        else if(tipoDeCafe == "latte" || tipoDeCafe == "Latte"){
            console.log("Elegiste un latte");
    
            acompaniamiento = prompt(`
            ${nombre} con que queres acompañar tu capuchino ?
    
            * Huevos revueltos 
            * Sandwich de jamon y queso
            * Pan de dulce de leche
            * Frutas
            `)
    
            if(acompaniamiento == "Huevos revueltos" || acompaniamiento == "huevos revueltos"){
                console.log(`${nombre}, disfruta de tu cafe y huevos revueltos`);
            }
            else if(acompaniamiento == "Sandwich de jamon y queso" || acompaniamiento == "sandwich de jamon y queso"){
                console.log(`${nombre}, disfruta de tu cafe y sandwich de jamon y queso`);
            }
            else if(acompaniamiento == "Pan de dulce de leche" || acompaniamiento == "pan de dulce de leche"){
                console.log(`${nombre}, disfruta de tu cafe y pan de dulce de leche`);
            }
            else if(acompaniamiento == "Frutas" || acompaniamiento == "frutas"){
                console.log(`${nombre}, disfruta de tu cafe y tus frutas`);
            }
            else{
                console.log("Elegiste nada");
            }
        }
        else if(tipoDeCafe == "cortado" || tipoDeCafe == "Cortado"){
            console.log("Elegiste un cortado");
    
            acompaniamiento = prompt(`
            ${nombre} con que queres acompañar tu capuchino ?
    
            * Huevos revueltos 
            * Sandwich de jamon y queso
            * Pan de dulce de leche
            * Frutas
            `)
    
            if(acompaniamiento == "Huevos revueltos" || acompaniamiento == "huevos revueltos"){
                console.log(`${nombre}, disfruta de tu cafe y huevos revueltos`);
            }
            else if(acompaniamiento == "Sandwich de jamon y queso" || acompaniamiento == "sandwich de jamon y queso"){
                console.log(`${nombre}, disfruta de tu cafe y sandwich de jamon y queso`);
            }
            else if(acompaniamiento == "Pan de dulce de leche" || acompaniamiento == "pan de dulce de leche"){
                console.log(`${nombre}, disfruta de tu cafe y pan de dulce de leche`);
            }
            else if(acompaniamiento == "Frutas" || acompaniamiento == "frutas"){
                console.log(`${nombre}, disfruta de tu cafe y tus frutas`);
            }
            else{
                console.log("Elegiste nada");
            }
        }
        else if(tipoDeCafe == "mocha" || tipoDeCafe == "Mocha"){
            console.log("Elegiste un mocha");
    
            acompaniamiento = prompt(`
            ${nombre} con que queres acompañar tu capuchino ?
    
            * Huevos revueltos 
            * Sandwich de jamon y queso
            * Pan de dulce de leche
            * Frutas
            `)
    
            if(acompaniamiento == "Huevos revueltos" || acompaniamiento == "huevos revueltos"){
                console.log(`${nombre}, disfruta de tu cafe y huevos revueltos`);
            }
            else if(acompaniamiento == "Sandwich de jamon y queso" || acompaniamiento == "sandwich de jamon y queso"){
                console.log(`${nombre}, disfruta de tu cafe y sandwich de jamon y queso`);
            }
            else if(acompaniamiento == "Pan de dulce de leche" || acompaniamiento == "pan de dulce de leche"){
                console.log(`${nombre}, disfruta de tu cafe y pan de dulce de leche`);
            }
            else if(acompaniamiento == "Frutas" || acompaniamiento == "frutas"){
                console.log(`${nombre}, disfruta de tu cafe y tus frutas`);
            }
            else{
                console.log("Elegiste nada");
            }
        }
        else if(tipoDeCafe == "chocolate" || tipoDeCafe == "Chocolate"){
            console.log("Elegiste un chocolate");
    
            acompaniamiento = prompt(`
            ${nombre} con que queres acompañar tu capuchino ?
    
            * Huevos revueltos 
            * Sandwich de jamon y queso
            * Pan de dulce de leche
            * Frutas
            `)
    
            if(acompaniamiento == "Huevos revueltos" || acompaniamiento == "huevos revueltos"){
                console.log(`${nombre}, disfruta de tu cafe y huevos revueltos`);
            }
            else if(acompaniamiento == "Sandwich de jamon y queso" || acompaniamiento == "sandwich de jamon y queso"){
                console.log(`${nombre}, disfruta de tu cafe y sandwich de jamon y queso`);
            }
            else if(acompaniamiento == "Pan de dulce de leche" || acompaniamiento == "pan de dulce de leche"){
                console.log(`${nombre}, disfruta de tu cafe y pan de dulce de leche`);
            }
            else if(acompaniamiento == "Frutas" || acompaniamiento == "frutas"){
                console.log(`${nombre}, disfruta de tu cafe y tus frutas`);
            }
            else{
                console.log("Elegiste nada");
            }
        }
        
    }else {
    
        console.log("ok... Tu te lo pierdes");
    }
}


